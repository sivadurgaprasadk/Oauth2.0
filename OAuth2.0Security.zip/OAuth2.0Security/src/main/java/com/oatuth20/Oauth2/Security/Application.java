package com.oatuth20.Oauth2.Security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

import com.oauth20.config.SecurityConfig;
import com.oauth20.config.WebConfig;

@Import(value = { WebConfig.class, SecurityConfig.class })
@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

}
